# Installation without CLI

## For users of Ubuntu 18.04 and upper.

1. Ubuntu 18.04 comes already with Suru icons installed;
2. Download Suru++ and unzip this zipped file and move the folder "Suru-Plus" to `your_name/.local/share/icons/`;
3. Rename "Suru-Plus" to "Suru++";
4. Apply "Suru++", using GNOME Tweak Tool.