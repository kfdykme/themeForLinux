# Installation without CLI

## For users of any ld Ubuntu versions and Ubuntu 16.04

1. Download Suru++ and unzip this zipped file and move the folder "Suru-Plus" to `your_name/.icons/` (16.04 and below) or `your_name/.local/share/icons/` (16.04.4 and above);
2. Rename "Suru-Plus" to "Suru++";
3. Apply "Suru++", using GNOME Tweak Tool.