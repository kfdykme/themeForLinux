# basil-tw
GRUB 2 Theme with the background that is Taiwan city style

### About the background picture
The background picture was downloaded as my wallpaper for years. I don't really remember where I download that.

After I search that via Google recently (2018), I believe the souce should be here: http://paperblue.net/Project/38505#sthash.yVPqkyBL.dpbs




